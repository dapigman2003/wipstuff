#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "ERROR: iOS device builds require macOS/Xcode." >&2
  exit 2
fi

bash scripts/validate-step21.sh

rm -rf artifacts/publish artifacts/Payload
mkdir -p artifacts/publish artifacts/logs

APP="$ROOT/artifacts/publish/StS2Launcher.Step05.iOS.app"
IPA="$ROOT/artifacts/StS2-Launcher-Step-21.ipa"
PROJECT="src/StS2Launcher.Step05.iOS/StS2Launcher.Step05.iOS.csproj"
PATCHER="tools/StS2Launcher.SteamKitIosPatcher/StS2Launcher.SteamKitIosPatcher.csproj"
FIXTURE_PROJECT="fixtures/StS2Launcher.Step16.Fixture/StS2Launcher.Step16.Fixture.csproj"
FIXTURE_DLL="$ROOT/fixtures/StS2Launcher.Step16.Fixture/bin/Release/net9.0/StS2Launcher.Step16.Fixture.dll"
STEP20_DYNAMIC_PROJECT="fixtures/StS2Launcher.Step20.DynamicFixture/StS2Launcher.Step20.DynamicFixture.csproj"
STEP20_DEPENDENCY_PROJECT="fixtures/StS2Launcher.Step20.DependencyFixture/StS2Launcher.Step20.DependencyFixture.csproj"
STEP20_ROOT_PROJECT="fixtures/StS2Launcher.Step20.RootFixture/StS2Launcher.Step20.RootFixture.csproj"
STEP20_DYNAMIC_DLL="$ROOT/fixtures/StS2Launcher.Step20.DynamicFixture/bin/Release/net9.0/StS2Launcher.Step20.DynamicFixture.dll"
STEP20_DEPENDENCY_DLL="$ROOT/fixtures/StS2Launcher.Step20.DependencyFixture/bin/Release/net9.0/StS2Launcher.Step20.DependencyFixture.dll"
STEP20_ROOT_DLL="$ROOT/fixtures/StS2Launcher.Step20.RootFixture/bin/Release/net9.0/StS2Launcher.Step20.RootFixture.dll"
PUBLISH_LOG="artifacts/logs/step21-publish.log"
PATCH_LOG="artifacts/logs/step21-steamkit-patch.log"

# Patch only a disposable repository-local SteamKit package copy.
export NUGET_PACKAGES="$ROOT/.nuget/packages"
rm -rf "$NUGET_PACKAGES/steamkit2/3.4.0"
mkdir -p "$NUGET_PACKAGES"

SDK_ROOT="$(xcrun --sdk iphoneos --show-sdk-path)"
if [[ -d "$SDK_ROOT/System/Library/Frameworks/DiskArbitration.framework" ]]; then
  echo "ERROR: DiskArbitration.framework unexpectedly exists in iPhoneOS SDK." >&2
  exit 3
fi

echo "Restoring Step 21 projects into isolated NuGet package root..."
dotnet restore "$PROJECT" 2>&1 | tee artifacts/logs/step21-restore.log
dotnet restore "$PATCHER" 2>&1 | tee artifacts/logs/step21-patcher-restore.log
dotnet restore "$FIXTURE_PROJECT" 2>&1 | tee artifacts/logs/step21-fixture-restore.log
dotnet restore "$STEP20_DYNAMIC_PROJECT" 2>&1 | tee artifacts/logs/step21-dynamic-fixture-restore.log
dotnet restore "$STEP20_DEPENDENCY_PROJECT" 2>&1 | tee artifacts/logs/step21-dependency-fixture-restore.log
dotnet restore "$STEP20_ROOT_PROJECT" 2>&1 | tee artifacts/logs/step21-root-fixture-restore.log

STEAMKIT_DLL="$NUGET_PACKAGES/steamkit2/3.4.0/lib/net8.0/SteamKit2.dll"
if [[ ! -f "$STEAMKIT_DLL" ]]; then
  echo "ERROR: restored SteamKit2 3.4.0 assembly not found: $STEAMKIT_DLL" >&2
  exit 6
fi

{
  echo "=== Step 21 SteamKit iOS compatibility patch ==="
  echo "Input: $STEAMKIT_DLL"
  if command -v shasum >/dev/null 2>&1; then
    echo "Before SHA-256: $(shasum -a 256 "$STEAMKIT_DLL" | awk '{print $1}')"
  fi
} | tee "$PATCH_LOG"

dotnet run --project "$PATCHER" -c Release --no-restore -- "$STEAMKIT_DLL" \
  2>&1 | tee -a "$PATCH_LOG"

if command -v shasum >/dev/null 2>&1; then
  echo "After SHA-256: $(shasum -a 256 "$STEAMKIT_DLL" | awk '{print $1}')" \
    | tee -a "$PATCH_LOG"
fi

for required in \
  'STEP05.16 STEAMKIT IOS PATCH: PASS' \
  'Assembly: SteamKit2 3.4.0' \
  'Process.StartTime status:'; do
  if ! grep -Fq "$required" "$PATCH_LOG"; then
    echo "ERROR: SteamKit patch telemetry missing: $required" >&2
    exit 7
  fi
done

if ! grep -Eq '^Replacement count: [01]$' "$PATCH_LOG"; then
  echo "ERROR: SteamKit patch telemetry must report replacement count 0 or 1." >&2
  exit 7
fi

echo "Building project-owned Step 16 regression managed fixture..."
dotnet build "$FIXTURE_PROJECT" -c Release --no-restore 2>&1 | tee artifacts/logs/step21-fixture-build.log
[[ -f "$FIXTURE_DLL" ]] || { echo "ERROR: Step 16 regression fixture assembly missing after build: $FIXTURE_DLL" >&2; exit 11; }

echo "Building project-owned Step 20 external managed fixtures as data-only payload..."
dotnet build "$STEP20_DYNAMIC_PROJECT" -c Release --no-restore 2>&1 | tee artifacts/logs/step21-dynamic-fixture-build.log
dotnet build "$STEP20_DEPENDENCY_PROJECT" -c Release --no-restore 2>&1 | tee artifacts/logs/step21-dependency-fixture-build.log
dotnet build "$STEP20_ROOT_PROJECT" -c Release --no-restore 2>&1 | tee artifacts/logs/step21-root-fixture-build.log
for fixture in "$STEP20_DYNAMIC_DLL" "$STEP20_DEPENDENCY_DLL" "$STEP20_ROOT_DLL"; do
  [[ -f "$fixture" ]] || { echo "ERROR: Step 20 external fixture missing after build: $fixture" >&2; exit 13; }
done

echo "Building/restoring pinned Godot 4.5.1 iOS static host (Step 15 regression dependency)..."
bash scripts/build-godot-step15.sh

echo "Publishing Step 21 Prepared Runtime / Framework Binding build..."
set +e
dotnet publish "$PROJECT" \
  --no-restore \
  -c Release \
  -f net9.0-ios \
  -r ios-arm64 \
  -p:BuildIpa=false \
  -p:EnableCodeSigning=false \
  -p:CodesignKey="" \
  -p:CodesignProvision="" \
  -p:AppBundleDir="$APP" \
  -bl:artifacts/logs/step21-dotnet-ios.binlog \
  2>&1 | tee "$PUBLISH_LOG"
PUBLISH_STATUS=${PIPESTATUS[0]}
set -e

if [[ "$PUBLISH_STATUS" != "0" ]]; then
  echo "=== Step 21 publish failed: focused scan ===" \
    | tee artifacts/logs/step21-failure-scan.log
  grep -E -m 160 \
    '(^|: )(error|fatal error)|undefined symbol|Undefined symbols|framework .+ not found|DiskArbitration|PlatformNotSupported|Authentication' \
    "$PUBLISH_LOG" | tee -a artifacts/logs/step21-failure-scan.log || true
  exit "$PUBLISH_STATUS"
fi

for required in \
  'STEP21 INTERPRETER POLICY: MtouchInterpreter=-all' \
  'UseInterpreter='; do
  if ! grep -Fq "$required" "$PUBLISH_LOG"; then
    echo "ERROR: Step 21 interpreter-policy telemetry missing from publish log: $required" >&2
    exit 15
  fi
done
if grep -F 'STEP21 INTERPRETER POLICY:' "$PUBLISH_LOG" | grep -Fq 'UseInterpreter=true'; then
  echo "ERROR: Step 21 publish unexpectedly resolved the broad UseInterpreter=true policy." >&2
  exit 15
fi
if grep -F 'STEP21 INTERPRETER POLICY:' "$PUBLISH_LOG" | grep -Fq 'PublishAot=true'; then
  echo "ERROR: Step 21 publish unexpectedly enabled NativeAOT." >&2
  exit 15
fi

BEFORE_LINE="$(grep 'STEP05.2 LINKER FRAMEWORKS BEFORE:' "$PUBLISH_LOG" | tail -1 || true)"
AFTER_LINE="$(grep 'STEP05.2 LINKER FRAMEWORKS AFTER:' "$PUBLISH_LOG" | tail -1 || true)"
if [[ -z "$BEFORE_LINE" || -z "$AFTER_LINE" ]]; then
  echo "ERROR: framework-filter telemetry was not emitted." >&2
  exit 8
fi
if [[ "$BEFORE_LINE" != *"DiskArbitration"* || "$AFTER_LINE" == *"DiskArbitration"* ]]; then
  echo "ERROR: proven DiskArbitration filter did not behave as expected." >&2
  exit 8
fi

if [[ ! -d "$APP" ]]; then
  echo "ERROR: publish completed but expected .app was not created: $APP" >&2
  exit 9
fi

SMOKE_DIR="$APP/Step15GodotSmokeProject"
rm -rf "$SMOKE_DIR"
cp -R "$ROOT/native/step15/smoke_project" "$SMOKE_DIR"
for required in project.godot Main.tscn Step15Smoke.gd; do
  [[ -f "$SMOKE_DIR/$required" ]] || { echo "ERROR: bundled Step 15 regression smoke-project file missing: $required" >&2; exit 10; }
done

FIXTURE_DIR="$APP/Step16Fixtures"
rm -rf "$FIXTURE_DIR"
mkdir -p "$FIXTURE_DIR"
cp "$FIXTURE_DLL" "$FIXTURE_DIR/StS2Launcher.Step16.Fixture.dll"
[[ -f "$FIXTURE_DIR/StS2Launcher.Step16.Fixture.dll" ]] || { echo "ERROR: bundled Step 16 regression fixture missing after copy." >&2; exit 12; }

STEP20_FIXTURE_DIR="$APP/Step20DynamicFixtures"
rm -rf "$STEP20_FIXTURE_DIR"
mkdir -p "$STEP20_FIXTURE_DIR"
cp "$STEP20_DYNAMIC_DLL" "$STEP20_FIXTURE_DIR/StS2Launcher.Step20.DynamicFixture.dll"
cp "$STEP20_DEPENDENCY_DLL" "$STEP20_FIXTURE_DIR/StS2Launcher.Step20.DependencyFixture.dll"
cp "$STEP20_ROOT_DLL" "$STEP20_FIXTURE_DIR/StS2Launcher.Step20.RootFixture.dll"
(
  cd "$STEP20_FIXTURE_DIR"
  shasum -a 256 \
    StS2Launcher.Step20.DynamicFixture.dll \
    StS2Launcher.Step20.DependencyFixture.dll \
    StS2Launcher.Step20.RootFixture.dll > step20-fixtures.sha256
)
for fixture in StS2Launcher.Step20.DynamicFixture.dll StS2Launcher.Step20.DependencyFixture.dll StS2Launcher.Step20.RootFixture.dll step20-fixtures.sha256; do
  [[ -f "$STEP20_FIXTURE_DIR/$fixture" ]] || { echo "ERROR: bundled Step 20 fixture payload missing after copy: $fixture" >&2; exit 14; }
done

mkdir -p artifacts/Payload
cp -R "$APP" artifacts/Payload/
(
  cd artifacts
  rm -f StS2-Launcher-Step-21.ipa
  /usr/bin/zip -qry StS2-Launcher-Step-21.ipa Payload
)

echo "Created $IPA"
