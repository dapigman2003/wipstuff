# Reference History Archive

This archive is non-authoritative reference material only.

It contains:

- historical step-specific shell wrappers as they existed before the Step 22.4 canonicalization;
- a snapshot of the legacy live iOS project directory named `StS2Launcher.Step05.iOS` immediately before it was renamed to `StS2Launcher.iOS`.

Nothing in this archive is an active build input. Current CI, validation, tests, documentation, and source must not depend on this archive. Historical step documentation is intentionally kept outside this archive under `docs/history/steps/` so the documentation tree remains directly readable without extracting anything.
