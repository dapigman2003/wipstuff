# 0.0.118 maintenance archive additions

This directory records the Step 32.0.3 active-surface trim. Everything in `history.zip` is inert historical material and must never be consumed by source, build, test, package, or runtime paths.

The complete pre-trim 0.0.117 source tree is preserved separately at `snapshots/StS2Launcher-Step32-0.0.117.zip`. That snapshot is the authoritative reconstruction source for every implementation/test/UI/fixture removed from the active 0.0.118 tree.

0.0.118 intentionally does not change the Step-32 Sentry/resolver behavior.
